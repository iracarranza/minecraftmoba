Minecraft MOBA Design Wiki
===========================

START
1. Unzip this folder anywhere on your computer.
2. Open index.html in Chrome, Firefox, Safari, or Edge.
3. Use the navigation bar to move between pages.

EDITING IN THE BROWSER
- Most body text is directly editable. Click it and type.
- Browser edits are stored locally using localStorage.
- "Export page JSON" creates a backup of the current page's editable content.
- "Import page JSON" restores a previously exported page.
- "Reset page" returns the page to the text currently written in the HTML file.

IMPORTANT
Browser edits do NOT rewrite the HTML source files themselves. If you want the files to be
the permanent/canonical version (for Git, sharing, version control, etc.), edit the HTML files
in a text editor such as VS Code, Codex, Sublime Text, or even TextEdit in plain-text mode.

ADDING A NEW PAGE
1. Duplicate any existing .html page.
2. Rename it.
3. Change its <title>, heading, and body content.
4. Add a navigation link for it to each page, or ask ChatGPT/Codex to do that mechanically.

FILES
- index.html          dashboard
- classes.html        classes / combat roles
- objectives.html     major structures and win pressure
- mechanics.html      Minecraft-native unique systems
- progression.html    XP / resources / items / crafting
- map.html            map, biomes, traversal, world rules
- balance.html        tuning and playtest notes
- inbox.html          rough ideas and unresolved questions
- styles.css          shared visual styling
- app.js              editing, local save, export/import

No server, package manager, install, or build step is required.
